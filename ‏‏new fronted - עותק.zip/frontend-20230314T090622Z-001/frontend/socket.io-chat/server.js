// סוקט - מעין מערכת צינורות בהם אנו מעבירים מידע 
// באפליקציה שלנו נשלח הודעות באמצעות סוקטים
// כלומר הודעות יעברו בצינור להעברת המידע , צינור זה נקרא סוקט
// כך נעביר מידע באופן מיידי וללא צורך ברענון של הדף

// setup
const express = require('express')
const app = express()

const http = require('http')
const server = http.createServer(app)

const { Server } = require('socket.io')
const io = new Server(server)

const msgs = []
let connectedUsers = []

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html')
})

// connection
io.on('connection', socket => {
    console.log('a user connected')

    // disconnect
    socket.on('disconnect', () => {
        connectedUsers = connectedUsers.filter(nickname => nickname !== socket.nickname)
        socket.broadcast.emit('chat-msg', { txt: `${socket.nickname} left (${connectedUsers.length})`, by: 'system' })
    })

    socket.on('join-topic', topic => {
        if (socket.topic !== topic) {
            socket.leave(socket.topic)
        }
        socket.topic = topic
        socket.emit('chat-history', msgs.filter(msg => msg.topic === socket.topic))
        socket.join(topic)
    })

    // join-chat: event when user join to chat,
    socket.on('join-chat', nickname => {
        socket.nickname = nickname
        socket.isNew = true

        connectedUsers.push(nickname)

        socket.broadcast.emit('chat-msg', { txt: `${nickname} connected (${connectedUsers.length})`, by: 'system' })
    })

    // chat-msg: event when user send msg from chat 
    socket.on('chat-msg', async msg => {
        msgs.push(msg)
        if (msg.to) {
            const toSocket = await _getUserSocket(msg.to)
            if (toSocket) toSocket.emit('chat-msg', msg)
        } else {
            io.to(msg.topic).emit('chat-msg', msg)
        }

        // if is first msg from user - show msg : 'Your response has been sent'
        if (socket.isNew) {
            setTimeout(() => socket.emit('chat-msg', { txt: 'Your response has been sent', by: 'system' }), 1500)
            socket.isNew = false
        }
    })
})

// return user Socket  instances
async function _getUserSocket(nickname) {
    const sockets = await _getAllSockets()
    const socket = sockets.find(s => s.nickname === nickname)
    return socket
}

// return all Socket (''pipes'') instances

async function _getAllSockets() {
    // return all Socket instances
    const sockets = await io.fetchSockets()
    return sockets
}

// run server we send on it the socket, example: chat msg 
server.listen(3003, () => {
    console.log('listening on *:3003')
})
