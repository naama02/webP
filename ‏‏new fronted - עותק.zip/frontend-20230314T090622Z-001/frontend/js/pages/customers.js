

async function onInitCustomers() {
    // TODO: IF WE WANT TO GET DATA FROM MONGO DB BY fetch REQ.
    // await fetch('http://127.0.0.1:3040/api/car')
    //     .then(response => response.json())
    //     .then(data => gItemsDB = data)
    //     .catch(error => console.error(error));

    renderCustomers()
    // console.log(gItemsDB, 'gItemsDB')
}

// renderCustomers()
// console.log('customers')
async function renderCustomers(gItemsFromDB) {
    // if (!gIsLoginUser) {
    //     alert('Not authorized to delete')
    //     return
    // }
    
    // <!-- todo: -->
    // console.log(gIsLoginUser,'gIsLoginUser')
    // if(!gIsLoginUser) return

    // TODO: IF WE WANT TO GET DATA FROM MONGO DB BY fetch REQ.
    // gItems = gItemsFromDB
    // const items = await getItemsForDisplay(gItemsFromDB)

    const items = await getCustomersForDisplay()

    // console.log(items, 'customers')

    const strHTMLs = items.map(item => `
        <div class="${(item.isSold) ? 'done' : ''} item"  data='${item._id}'>
        <img class="img-item" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHwAAAB8CAMAAACcwCSMAAAAYFBMVEUNmMf////89/cAk8XV5u4AkcQAlcb/+/kAjsL//foAi8H///3v9/qhyuHn8/i02Ond7PS/3etTqtClz+QvnMnM4++FwNxqtNWZyOBer9KRxd73+/x6uddCosw3pM0sn8rWH1B/AAAGa0lEQVRogbWb6XqzIBCFSRBc4r7H5cv93+WHmtYkDnIw9vRP+zyVlx1mmGEXe8VVEtVN/u/BlB5j3tRF4oQHCmK23DYvpeRcSvYr9bf6Ke9FZVkDC3ifKrDgL9R3ScFVBdK/gMfdyIUWvFZA5kV8Mjy5C24Crx3QVOfBw0ia2/zG91hxDjyuOdroF3EWmWefCd537AB6xpdF/x08eYhj6EliNIz9Ljy+e8fRbJp7w27f78Fbz2qakXieHYLH4xc9vspr9COvhWfs62Yv4qVjC+8OznFCUuoWvQbenNLlPxKdBbwfz2v3Qr/D8Pis4V7FR2raEfC0PJ2tBn4kVvwW/idsmr6Bx3/Dnuhm+F+xFT03wf+hbCmCeff1AiHBb8SwDx+wNSaDsc7iq+v7rhtmXe5hn3nRHjyC9hbOhtR13etT6tewKyG8yPTwCuo/OcT+9UN+2GGdn+rgITLZpMw26BnvjMjXuQ5+R74uQ5Kter/Pge/ftvkXeAJcW2R5o9GTbgg9SCl4iIxZGevZ12uP9HxJwZFVxjN3D+46SMcXW7gDrDI57LIVHbqDxBs4Ml5yt9MnhaW5FD58wjOo4ZqJvspvkcFzPuBAjZmXmtiq6ciSyd/hCTJWD8OIz6OODB+v3uAPgC1rBN4ic+f+Cs+QhvMEgF8r5GwS6Qsc6SvmGef6pD4AipL1Co+RD1iANPx6g2zLYIV30Gno7WzrL3CoLJH8wHtknam+wuDI3H2utglegVY4BsdugSJ+wgfwAngmnBcLHNmP58picKywud8Zdp5NAiccat/GMxw1xYMegkPLdrnIMnCHYdi5ok4WEC6bCR6DQ266xjwFba+TxglewU7V7qyDZVGq4AVaVXlH4Oi6nQadXRq4qhKBo4UxHik4tB3OQmZcDPss1YxjPW6Pc/Og+wXuSnpcWIzDZW7udXwQGbswzDJdxI3XiRgvTF3EWWYBF63JaEgsnIfSYRaDxJip313E0P2FZ3Zw7uzDUxtvEk9YZAM32Cx+Z+Oy5YUd3GCt9TZF2cN5u9N0F7J71rIiS/juLfKGno9H4bzQrjYXsnu+gTOm7XcfcYq8wm3HfPJqaJruojfwF7jVOp+lucpBxvEbPLGHi4hsunXDpx3ObnlMGsmmW51nC7yyOlgWCXKPhe+hKzxliOvsXR55i0VNjxd4yELrbvdID4Vj/+ar7nDW32i63bYYZa0x2GBZP6InHPhIsZZTK3ht+RF36F0G8ta/SCQKjvgeV0kde5rvdodapeA20116Q6+/xt068KFnVhkqeD/CZFZvX1fexr1vSzTaYPIOKBMZ2Zok548m22n1D/7qDEgk0XQtmeGm664UssxbJ/QhP9zV753iXhrDeoQzw3dXKOfsHlUo+Kf9UwUa9e1OBR7h4o3SrnTpla3j24HXCtzSYgy0RTdPV5juVPXy6nYI/FuBW9podl2vesJjetC9wv0KvfA1F7uy//G9kkYOTyDXl0k+aYkubucZTs133p3CVnTqurI87S3+dgJeQl43iE44RB8vzv6tz5t3xpckVO729ODJC3w75UT1/WT7hW/6Xb498GwcWDI/Db51LPPoDb41rHl9Ur/727OjDN8f9bb/ISBvp5ndboe0/XhRJJxSQXoC3c22juCy/4BfCKcC/57uEpdaL7l8won3Bll+S3eJ7e0lbGJ9vM+2dfyW7lZEfJmXEnBqh/+Ortq9LZLXFwreE6efFNrLqlE+0ZeqJy4knL5EB8XB9e7X1IOHSDVwOmZDDM4h5WRhb9FRb3A6zAYN+gK+4s1FC7+kRzAWFfqIBvwISbP2bVhJfOQcfAbjJeCz2BEFn6G/mzDE7TlwlrxNzPU2+tPKc2whvg06JuJebQ32w2wy4rf7g1nnUcHWZKxze/qsC8gYezrKG4nLs5AUdIi7JsScOgsPi4+anCJdcH1Kbs2HJBpdVoU+p6E+Z8lJHmkRO9kclV3OEC3OdtK49lJJep1xjTfbq3fKN2TwVN+lk3j5fvaaIX2oL46mLk05JMl+4easrbg+hudla0zbAvLV4nrPq6RBSzMazNTrW2aTxiS9h6nDLeBKVSMxvvTYoM0XOghX9lRy38vNnMFclE1mSpE7Ar9MWal1XtKeVTklhuadXWaqZVLsVIFi+KdYU2bsIjllyOZDYpsSewC+KEyrLCmKqCiKJKvSI7nASv8BD0xbPRgteAsAAAAASUVORK5CYII=">
        
        <div class="details-customer flex column">
        <span class="title">Name: ${item.name}</span > 
        <span class="price">Phone: ${item.phone}</span > 
        </div>

            <div  class="actions flex column">
             <div class="flex">
                <button onclick="onUpdateCustomer('${item._id}')" class="add-btn">Edit</button>
                <button onclick="onSaveChangesCustomer('${item._id}')" class="add-btn">Save</button>
                <button class="add-btn" onclick="onRemoveCustomer(event,'${item._id}')" >X</button>
             </div>
            
              

            </div>
        </div>
    `)

    document.querySelector('.customers').innerHTML = strHTMLs.join('')
    // document.querySelector('span.total').innerText = await getTotalCount()
    // document.querySelector('span.active').innerText = await getActiveCount()

    // console.log(strHTMLs.join(''), 'strHTMLs')
}


function onRemoveCustomer(ev, itemId) {
    ev.stopPropagation()
    // console.log('Removing:', itemId)
    removeCustomer(itemId)
    renderCustomers()
}

function onAddCustomer(ev) {
    ev.preventDefault()
    const elTxt = document.querySelector('[name=name]')
    const name = elTxt.value

    const elPrice = document.querySelector('[name=phone]')
    const phone = elPrice.value
    addCustomer(name, phone)
    renderCustomers()
    elTxt.value = ''
}


function onClickInputCustomer(ev, clickedBtn) {
    // console.log(typeof ev.target.value, 'ev')
    // console.log(ev, 'ev')

    saveTxtInputCustomer(ev, clickedBtn)
}


function onUpdateCustomer(itemId) {

    // console.log(itemId, 'itemId to edit')

    const idx = gCustomers.findIndex(item => item._id === itemId)
    // console.log(idx, 'idx')
    const elTxt = document.querySelector('[name=name]').value = gCustomers[idx].name
    const elPrice = document.querySelector('[name=phone]').value = gCustomers[idx].phone

    updateIdToEditCustomer(itemId)
    renderCustomers()
}

function onSetFilterByStatusCustomer(txt) {
    // console.log('Filtering by txt', txt)
    setFilterByTxtCustomer(txt)
    renderCustomers()
}

function onSetFilterByTxtCustomer(txt) {
    // console.log('Filtering by txt', txt)
    setFilterByTxtCustomerTEXT(txt)
    renderCustomers()
}

function onSaveChangesCustomer(itemId) {

    editCustomer(itemId)
    renderCustomers()
}


function check(){
    console.log(gIsLoginUser,'gIsLoginUser')
}