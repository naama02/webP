// gSellers

let gStars = [
  {
    name: 'Shabi',
    rate: 100,
    color: getRandomColor()
  },
  {
    name: 'Uza',
    rate: 130,
    color: getRandomColor()
  },
  {
    name: 'Batz',
    rate: 150,
    color: getRandomColor()
  },
  {
    name: 'Puki',
    rate: 120,
    color: getRandomColor()
  },
  {
    name: 'Muki',
    rate: 110,
    color: getRandomColor()
  },
  {
    name: 'Shraga',
    rate: 10,
    color: getRandomColor()
  }
]

let gElCanvas
let gCtx

const BAR_WIDTH = 40


function initChart() {
  // <canvas id="my-canvas" height="400" width="400" onclick="canvasClicked(event)"> </canvas>
  gElCanvas = document.getElementById('my-canvas')
  gCtx = gElCanvas.getContext('2d')
  gCtx.fillStyle = '#10a9f4' // blue
  gCtx.fillRect(0, 0, gElCanvas.width, gElCanvas.height)
  drawCharts()
}

function drawCharts() {

  const barSpace = 20

  gStars.forEach((star, idx) => {
    // const { rate, color } = star

    const  rate = star.rate
    const  color = star.color


    gCtx.fillStyle = color
    star.x = idx * (BAR_WIDTH + barSpace)
    star.y = gElCanvas.height - rate
    gCtx.fillRect(star.x, star.y, BAR_WIDTH, rate)
  })
  console.log('gStars:', gStars)
}

function canvasClicked(ev) {
  console.log('Click on me canvas')
  // TODO: find out if clicked a star bar
  const clickedStar = gStars.find(star => {
    // Check if the click coordinates are inside the bar coordinates
    return ev.offsetX > star.x && ev.offsetX < star.x + BAR_WIDTH &&
      ev.offsetY > star.y && ev.offsetY < star.y + star.rate
  })
  console.log(clickedStar)
  // TODO: open the modal on the clicked coordinates if found a click on the star bar
  if (clickedStar) {
    const { name, rate } = clickedStar
    openModal(name, rate, ev.clientX, ev.clientY)
    // close the modal otherwise
  } else closeModal()
}

function openModal(name, starRate, x, y) {
  // open the modal with the given text in the given coordinates 
  const elModal = document.querySelector('.modal')

 
  elModal.innerText = `${name}  ,in the current month, increased the sales rate of the iPhone by ${starRate}% `
  elModal.style.left = `${x}px`
  elModal.style.top = `${y}px`
  elModal.hidden = false
}

function closeModal() {
  // close modal
  document.querySelector('.modal').hidden = true
}
// #10a9f4
function getRandomColor() {
  const letters = '0123456789ABCDEF'
  let color = '#'
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)]
  }
  return color
}

