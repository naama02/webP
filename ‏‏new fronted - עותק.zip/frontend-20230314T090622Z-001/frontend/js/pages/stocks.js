
// renderStocks()

async function renderStocks() {

    
    const items = await getStocksData()
    const dateForStock = prompt('date? || ,date for example: 2023-03-08 ,|| Please note: a date of at least one day in advance is given to the voucher')
    // dateForStock = '2023-03-08'

    //items = {Meta Data: {…}, Time Series (Daily): {2023-03-07:{1. open:152$},.............,2023-03-08:{1. open:152$}}}
    const stock = items['Time Series (Daily)'][dateForStock]['1. open'] + '$'

    const strHTMLs =
        `
    <div class="headline-stock-page">
      Apple's stock rate on: ${dateForStock} stood on: ${stock}
    </div>
`
    document.querySelector('.stock-info').innerHTML = strHTMLs
}


