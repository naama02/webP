


function onInitAboutPage() {
    initMap()
}