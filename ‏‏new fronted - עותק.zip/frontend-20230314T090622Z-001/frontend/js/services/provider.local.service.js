'use strict'
let gProviderDescribedEdit = {
    _id: '',
    name: '',
    phone: ''
}

const CUSTOMER_STORAGE_KEY = 'providerDB'
// var gDescribedEdit = {
//     txt: '',
//     price: '',
//     id: ''
// }

var gProvidersFilterBy = {
    name: '',
    status: '',
}
var gProviders
let gProvidersFromDB = null

_createProviders()

function getProvidersForDisplay() {
    var providers = gProviders

    console.log('gProvidersFilterBy $$@@!!@', gProvidersFilterBy)
    // console.log('gProvidersFilterBy', gProvidersFilterBy)

    saveToStorage(CUSTOMER_STORAGE_KEY, gProviders)
    // un-happy-provider
    if (gProvidersFilterBy.status) {
        providers = providers.filter(provider =>
            (provider.status === gProvidersFilterBy.status)
        )
    }

    providers = providers?.filter(provider => provider?.name?.toLowerCase().includes(gProvidersFilterBy.name.toLowerCase()))
    return providers
    return Promise.resolve(providers)
}

function removeProvider(providerId) {
    const providerIdx = gProviders.findIndex(provider => provider._id === providerId)
    gProviders.splice(providerIdx, 1)
    _saveProvidersToStorage()
}

function toggleProvider(providerId) {
    console.log(gProviders, 'gProviders')
    console.log(providerId, 'providerId')
    const provider = gProviders?.find(provider => provider._id === providerId)
    provider.isSold = !provider.isSold

    // TODO: if we want work local
    _saveProvidersToStorage()
}


function addProvider(name, phone, id) {

    const provider = _createProvider(name, phone)
    gProviders.push(provider)

    store(CUSTOMER_STORAGE_KEY, gProviders)
    return Promise.resolve(provider)
}


function editProvider(providerId, textProvider, priceProvider) {

    const idx = gProviders.findIndex(provider => provider._id === gProviderDescribedEdit._id)
    console.log(idx, 'idx')
    let newProvider = gProviders[idx]
    console.log(gProviderDescribedEdit._id, 'provider Id to edit')

    newProvider.name = gProviderDescribedEdit.name
    newProvider.phone = gProviderDescribedEdit.phone

    console.log(newProvider, 'newProvider')
    gProviders.splice(idx, 1, newProvider)

    store(CUSTOMER_STORAGE_KEY, gProviders)
    return Promise.resolve(newProvider)

}

// function get(entityType, entityId) {
//     return query(entityType)
//         .then((entities) =>
//             entities.find((entity) => entity._id === entityId)
//         )
// }


function setFilterByTxtProvider(status) {
    gProvidersFilterBy.status = status
}



function setFilterByTxtProviderTEXT(name) {
    gProvidersFilterBy.name = name
}

function getTotalCountProviders() {
    // return Promise.resolve(gProviders.length)
    return gProviders.length
}

function getActiveProviders() {
    // return Promise.resolve(gProviders.filter(provider => !provider.isSold).length)
    return gProviders.filter(provider => !provider.isSold).length
}


function _createProviders() {
    var providers = loadFromStorage(CUSTOMER_STORAGE_KEY)

    if (!providers || !providers.length) {
        providers = [
            {
                _id: 'c101',
                name: 'Provider 1',
                email: 'c101@gmail.com',
                phone: '0525381648',
                status: 'happy-provider'
            },
            {
                _id: 'c102',
                name: 'Provider 2',
                email: 'c102@gmail.com',
                phone: '0525381648',
                status: 'happy-provider'
            },
            {
                _id: 'c103',
                name: 'Provider 3',
                email: 'c103@gmail.com',
                phone: '0525381648',
                status: 'un-happy-provider'
            },
            {
                _id: 'c104',
                name: 'Provider 4',
                email: 'c104@gmail.com',
                phone: '0525381648',
                status: 'happy-provider'
            },

            {
                _id: 'c105',
                name: 'Provider 5',
                email: 'c104@gmail.com',
                phone: '0525381648',
                status: 'happy-provider'
            },
        ]
    }

    // TODO: if we want work local
    gProviders = providers
    console.log(gProviders, 'gProviders...')
    _saveProvidersToStorage()
}


function _createProvider(name, phone) {
    const provider = {
        id: _makeId(),
        name,
        phone
    }
    return provider
}


function _saveProvidersToStorage() {
    saveToStorage(CUSTOMER_STORAGE_KEY, gProviders)
}

function _makeId(length = 5) {
    var txt = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (var i = 0; i < length; i++) {
        txt += characters.charAt(Math.floor(Math.random() * characters.length));
    }

    return txt;
}


function store(key, value) {
    localStorage[key] = JSON.stringify(value);
}

function load(key, defaultValue = null) {
    var value = localStorage[key] || defaultValue;
    return JSON.parse(value);
}

function saveTxtInputProvider(ev, clickedBtn) {
    console.log(clickedBtn, 'clickedBtn')
    const value = ev.target.value
    const txt = (clickedBtn.name === 'name') ? gProviderDescribedEdit.name = value : gProviderDescribedEdit.name
    const price = (clickedBtn.name === 'phone') ? gProviderDescribedEdit.phone = value : gProviderDescribedEdit.phone

    console.log(gProviderDescribedEdit, 'gProviderDescribedEdit')

    // console.log(valueToPass, 'valueToPass')
    // gDescribedEdit.txt = value
    // console.log(gDescribedEdit, 'gDescribedEdit')
}

function updateIdToEditProvider(providerId) {
    console.log(providerId, '%%%%%')
    gProviderDescribedEdit._id = providerId
    console.log('gProviderDescribedEdit', gProviderDescribedEdit)
}

function saveToStorage(key, val) {
    const str = JSON.stringify(val)
    localStorage.setItem(key, str)
}

function loadFromStorage(key) {
    const str = localStorage.getItem(key)
    return JSON.parse(str)
}


