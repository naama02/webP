'use strict'
let gCustomerDescribedEdit = {
    _id: '',
    name: '',
    phone: ''
}

const CUSTOMER_STORAGE_KEY = 'customerDB'
// var gDescribedEdit = {
//     txt: '',
//     price: '',
//     id: ''
// }

var gCustomersFilterBy = {
    name: '',
    status: '',
}
var gCustomers
let gCustomersFromDB = null

_createCustomers()

function getCustomersForDisplay() {
    var customers = gCustomers

    // console.log('gCustomersFilterBy $$@@!!@', gCustomersFilterBy)
    // console.log('gCustomersFilterBy', gCustomersFilterBy)

    saveToStorage(CUSTOMER_STORAGE_KEY, gCustomers)
    // un-happy-customer
    if (gCustomersFilterBy.status) {
        customers = customers.filter(customer =>
            (customer.status === gCustomersFilterBy.status)
        )
    }

    // console.log('customers $$@@!!@', customers)

    customers = customers?.filter(customer => customer?.name?.toLowerCase().includes(gCustomersFilterBy.name.toLowerCase()))
    return customers
    return Promise.resolve(customers)
}

function removeCustomer(customerId) {
    
    const customerIdx = gCustomers.findIndex(customer => customer._id === customerId)
    gCustomers.splice(customerIdx, 1)
    _saveCustomersToStorage()
}

function toggleCustomer(customerId) {
    // console.log(gCustomers, 'gCustomers')
    // console.log(customerId, 'customerId')
    const customer = gCustomers?.find(customer => customer._id === customerId)
    customer.isSold = !customer.isSold

    // TODO: if we want work local
    _saveCustomersToStorage()
}


function addCustomer(name, phone, id) {

    const customer = _createCustomer(name, phone)
    gCustomers.push(customer)

    store(CUSTOMER_STORAGE_KEY, gCustomers)
    return Promise.resolve(customer)
}


function editCustomer(customerId, textCustomer, priceCustomer) {

    const idx = gCustomers.findIndex(customer => customer._id === gCustomerDescribedEdit._id)
    // console.log(idx, 'idx')
    let newCustomer = gCustomers[idx]
    // console.log(gCustomerDescribedEdit._id, 'customer Id to edit')

    newCustomer.name = gCustomerDescribedEdit.name
    newCustomer.phone = gCustomerDescribedEdit.phone

    // console.log(newCustomer, 'newCustomer')
    gCustomers.splice(idx, 1, newCustomer)

    store(CUSTOMER_STORAGE_KEY, gCustomers)
    return Promise.resolve(newCustomer)

}

// function get(entityType, entityId) {
//     return query(entityType)
//         .then((entities) =>
//             entities.find((entity) => entity._id === entityId)
//         )
// }


function setFilterByTxtCustomer(status) {
    gCustomersFilterBy.status = status
}



function setFilterByTxtCustomerTEXT(name) {
    gCustomersFilterBy.name = name
}

function getTotalCountCustomers() {
    // return Promise.resolve(gCustomers.length)
    return gCustomers.length
}

function getActiveCustomers() {
    // return Promise.resolve(gCustomers.filter(customer => !customer.isSold).length)
    return gCustomers.filter(customer => !customer.isSold).length
}


function _createCustomers() {
    var customers = loadFromStorage(CUSTOMER_STORAGE_KEY)

    if (!customers || !customers.length) {
        customers = [
            {
                _id: 'c101',
                name: 'Customer 1',
                email: 'c101@gmail.com',
                phone: '0525381648',
                status: 'happy-customer'
            },
            {
                _id: 'c102',
                name: 'Customer 2',
                email: 'c102@gmail.com',
                phone: '0525381648',
                status: 'happy-customer'
            },
            {
                _id: 'c103',
                name: 'Customer 3',
                email: 'c103@gmail.com',
                phone: '0525381648',
                status: 'un-happy-customer'
            },
            {
                _id: 'c104',
                name: 'Customer 4',
                email: 'c104@gmail.com',
                phone: '0525381648',
                status: 'happy-customer'
            },

            {
                _id: 'c105',
                name: 'Customer 5',
                email: 'c104@gmail.com',
                phone: '0525381648',
                status: 'happy-customer'
            },
        ]
    }

    // TODO: if we want work local
    gCustomers = customers
    // console.log(gCustomers, 'gCustomers...')
    _saveCustomersToStorage()
}


function _createCustomer(name, phone) {
    const customer = {
        id: _makeId(),
        name,
        phone
    }
    return customer
}


function _saveCustomersToStorage() {
    saveToStorage(CUSTOMER_STORAGE_KEY, gCustomers)
}

function _makeId(length = 5) {
    var txt = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (var i = 0; i < length; i++) {
        txt += characters.charAt(Math.floor(Math.random() * characters.length));
    }

    return txt;
}


function store(key, value) {
    localStorage[key] = JSON.stringify(value);
}

function load(key, defaultValue = null) {
    var value = localStorage[key] || defaultValue;
    return JSON.parse(value);
}

function saveTxtInputCustomer(ev, clickedBtn) {
    // console.log(clickedBtn, 'clickedBtn')
    const value = ev.target.value
    const txt = (clickedBtn.name === 'name') ? gCustomerDescribedEdit.name = value : gCustomerDescribedEdit.name
    const price = (clickedBtn.name === 'phone') ? gCustomerDescribedEdit.phone = value : gCustomerDescribedEdit.phone

    // console.log(gCustomerDescribedEdit, 'gCustomerDescribedEdit')

    // console.log(valueToPass, 'valueToPass')
    // gDescribedEdit.txt = value
    // console.log(gDescribedEdit, 'gDescribedEdit')
}

function updateIdToEditCustomer(customerId) {
    // console.log(customerId, '%%%%%')
    gCustomerDescribedEdit._id = customerId
    // console.log('gCustomerDescribedEdit', gCustomerDescribedEdit)
}

function saveToStorage(key, val) {
    const str = JSON.stringify(val)
    localStorage.setItem(key, str)
}

function loadFromStorage(key) {
    const str = localStorage.getItem(key)
    return JSON.parse(str)
}


