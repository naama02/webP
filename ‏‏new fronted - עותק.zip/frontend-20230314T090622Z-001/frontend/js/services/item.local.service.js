'use strict'

const STORAGE_KEY = 'itemDB'
var gDescribedEdit = {
    txt: '',//k
    price: '',//120
    id: ''
}

var gFilterBy = {
    txt: '',
    status: '',
    label: 'All'
}

// var gFilterBy = {
//     txt: '',
//     status: 'sold'
// }



// [{_id: 'i103', txt: 'Iphone 8', isSold: false, price: 400, imgSrc: ''},{..},{..}] => filter  =>[{_id: 'i103', txt: 'Iphone X', isSold: false, price: 400, imgSrc: ''}]
var gItems
let gItemsFromDB = null

_createItems()





function getItemsForDisplay(itemsDB) {
    var items = gItems
    const label = gFilterBy.label

    saveToStorage(STORAGE_KEY, gItems)

    if (gFilterBy.status) {
        items = items.filter(item =>
            (item.isSold && gFilterBy.status === 'sold') ||
            (!item.isSold && gFilterBy.status === 'active')
        )
    }

    // if()
    // IPHONE => iphone


    if (gFilterBy.label !== 'All') {
        items = items.filter((iphone) => iphone.labels.includes(label))
    }


    items = items?.filter(item => item.txt.toLowerCase().includes(gFilterBy.txt.toLowerCase()))
    return items

}

function removeItem(itemId) {
    if (!gIsLoginUser) {
        alert('Not authorized to delete')
        return
    }
    const itemIdx = gItems.findIndex(item => item._id === itemId)

    gItems.splice(itemIdx, 1)
    _saveItemsToStorage()
}

function toggleItem(itemId) {
    // console.log(gItems, 'gItems')
    // console.log(itemId, 'itemId')
    if (!gIsLoginUser) {
        alert('Not authorized to delete')
        return
    }

    const item = gItems?.find(item => item._id === itemId)
    item.isSold = !item.isSold

    // TODO: if we want work local
    _saveItemsToStorage()
}


function addItem(txt, price, id) {
    if (!gIsLoginUser) {
        alert('Not authorized to delete')
        return
    }

    const item = _createItem(txt, price)
    gItems.push(item) // gItems = [{...},{...},{item}] /

    store(STORAGE_KEY, gItems)
    return Promise.resolve(item)
}


function edit(itemId, textItem, priceItem) {
    // console.log(gDescribedEdit._id, 'item Id to edit')
    if (!gIsLoginUser) {
        alert('Not authorized to delete')
        return
    }

    const idx = gItems.findIndex(item => item._id === gDescribedEdit._id)
    console.log(idx, 'idx')
    let newItem = gItems[idx]

    // gItems = [{old},{}{},{}}]

    // {_id: 'i101', txt: 'Iphone 8', isSold: true, price: 100, imgSrc: ''} // old // in gItems[0]
    // {_id: 'i101', txt: 'Iphone 81', isSold: true, price: 344, imgSrc: ''} // new // in gDescribedEdit

    // After 
    // {_id: 'i101', txt: 'Iphone 81', isSold: true, price: 344, imgSrc: ''}
    //gItems =  [{newItem},{}{},{}}]


    newItem.txt = gDescribedEdit.txt
    newItem.price = gDescribedEdit.price

    // console.log(newItem, 'newItem')
    gItems.splice(idx, 1, newItem)

    store(STORAGE_KEY, gItems)
    return Promise.resolve(newItem)

}

// function get(entityType, entityId) {
//     return query(entityType)
//         .then((entities) =>
//             entities.find((entity) => entity._id === entityId)
//         )
// }


// setFilter('active') 

// var gFilterBy = {
//     txt: '',
//     status: 'active'
// }

function setFilter(status) {
    gFilterBy.status = status
}

function setFilterByTxt(txt) {
    gFilterBy.txt = txt
}

function setFilterByLable(lable) {
    gFilterBy.label = lable
}
// html (8)
// main.js (8)
// service (8)
// gFilterBy ={txt:8, status:'}

function getTotalCount() {
    // return Promise.resolve(gItems.length)
    return gItems.length
}

function getActiveCount() {
    // return Promise.resolve(gItems.filter(item => !item.isSold).length)
    return gItems.filter(item => !item.isSold).length
}


function _createItems() {
    var items = loadFromStorage(STORAGE_KEY)
    // []
    if (!items || !items.length) {
        items = [
            {
                _id: 'i101',
                txt: 'Iphone 8',
                isSold: true,
                price: 100,
                imgSrc: '',
                labels: ['white', '256 gb', '8 RAM']
            },
            {
                _id: 'i102',
                txt: 'Iphone 9',
                isSold: false,
                price: 300,
                imgSrc: '',
                labels: ['white', '128 gb', '8 RAM']
            },
            {
                _id: 'i103',
                txt: 'Iphone X',
                isSold: false,
                price: 400,
                imgSrc: '',
                labels: ['white', '128 gb', '6 RAM']
            },
            {
                _id: 'i104',
                txt: 'Iphone 11',
                isSold: false,
                price: 500,
                imgSrc: '',
                labels: ['white', '128 gb', '8 RAM']
            },

            {
                _id: 'i105',
                txt: 'Iphone 12',
                isSold: false,
                price: 600,
                imgSrc: '',
                labels: ['white', '128 gb', '6 RAM']
            },
            {
                _id: 'i105',
                txt: 'Iphone 13',
                isSold: false,
                price: 700,
                imgSrc: '',
                labels: ['white', '128 gb', '6 RAM']
            },
        ]
    }

    // TODO: if we want work local
    gItems = items
    _saveItemsToStorage()
}


function _createItem(txt, price) {
    const item = {
        id: _makeId(),
        txt,
        isSold: false,
        price
    }
    return item
}


function _saveItemsToStorage() {
    saveToStorage(STORAGE_KEY, gItems)
}

function _makeId(length = 5) {
    var txt = '';
    var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (var i = 0; i < length; i++) {
        txt += characters.charAt(Math.floor(Math.random() * characters.length));
    }

    return txt;
}


function store(key, value) {
    localStorage[key] = JSON.stringify(value);
}

function load(key, defaultValue = null) {
    var value = localStorage[key] || defaultValue;
    return JSON.parse(value);
}

function saveTxtInput(ev, clickedBtn) {
    console.log(clickedBtn, 'clickedBtn')
    const value = ev.target.value //ww
    const txt = (clickedBtn.name === 'txt') ? gDescribedEdit.txt = value : gDescribedEdit.txt
    const price = (clickedBtn.name === 'price') ? gDescribedEdit.price = value : gDescribedEdit.price

    // Example
    // const txt = 'new device'
    // const price = 122
    console.log(gDescribedEdit, 'gDescribedEdit')

    // console.log(valueToPass, 'valueToPass')
    // gDescribedEdit.txt = value
    // console.log(gDescribedEdit, 'gDescribedEdit')
}

function updateIdToEdit(itemId) {
    if (!gIsLoginUser) {
        alert('Not authorized to delete')
        return
    }

    gDescribedEdit._id = itemId
    console.log('gDescribedEdit', gDescribedEdit)
}

function unAuth() { gIsLoginUser = !gIsLoginUser }