
async function getStocksData() {
    try {
        const response = await fetch(
            `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=AAPL&apikey={WIH4G99Z2KP6FVJW}`
        );
        const data = await response.json();
        console.log('data', data)
        return data;
    }
    catch (error) {
        console.log(error);
    }
}




// not in use:  

function setData(data) {
    let stockInfo = []
    for (const property in data) {
        stockInfo.push(`${property}: ${data[property]}`)
        console.log(`${property}: ${data[property]}`)
    }
    console.log(stockInfo, 'stockInfo')
    return stockInfo
}


function getDate() {

    var currentDate = new Date();

    var y = makeDigitsOrder(currentDate.getFullYear())
    var m = makeDigitsOrder(currentDate.getMonth() + 1)
    var d = makeDigitsOrder(currentDate.getDay())
    var dateTime = y + '-' + m + "-" + d
    console.log(dateTime)
    return dateTime


}

function makeDigitsOrder(time) {
    const t = time.toString().split()//['3']
    console.log('t', t)


    if (t.length > 1) {
        console.log('time', time)
        return time
    }
    else {
        console.log(`0` + t.join(''))
        return `0` + t.join('')
    }
}