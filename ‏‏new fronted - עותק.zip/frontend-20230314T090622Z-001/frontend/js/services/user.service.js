const KEY = 'userDB'
const STORAGE_KEY_LOGGEDIN_USER = 'loggedInUser'

// signup({ fullname: 'Puki ja', username: 'puki', password: 'secret' })
// signup({ fullname: 'Muki la', username: 'muki', password: 'secret 2' })
// signup({ fullname: 'miki ma', username: 'miki', password: '1234' })



// let gIsRunOneTime = true
// runOneTime()
// function addUsers() {
//     signup({ fullname: 'Puki ja', username: 'puki', password: 'secret' })
//     signup({ fullname: 'Muki la', username: 'muki', password: 'secret 2' })
//     signup({ fullname: 'miki ma', username: 'miki', password: '1234' })

// }
// async function runOneTime() {
//     if (!gIsRunOneTime) return
//     console.log('first')
//     await addUsers()
//     gIsRunOneTime = false

// }


function getLoggedInUser() {
    return { fulllname: 'is connected' }
    console.log(JSON.parse(sessionStorage.getItem(STORAGE_KEY_LOGGEDIN_USER)))
    const info = JSON.parse(sessionStorage.getItem(STORAGE_KEY_LOGGEDIN_USER))

    // return JSON.parse(sessionStorage.getItem(STORAGE_KEY_LOGGEDIN_USER))
    // return info
}

// todo...
// function login({ username, password }) {
function login(cred) {

    console.log(cred, '%%%% cred %%%%')
    //  gCred = { username: 'aaa', password: '123' }

    return queryAsync(KEY)
        .then(users => {
            const user = users.find(user => user.username === cred.username)
            const pass = users.find(user => user.password === cred.password)

            if (user && pass) return setLoggedinUser(user)
            else {
                alert('Invalid login')
                return Promise.reject('Invalid login')
            }
        })
}
function signup({ username, password, fullname }) {
    console.log('signup')
    const user = { username, password, fullname }
    return post(KEY, user)
        .then(setLoggedinUser)
}

function setLoggedinUser(user) {
    console.log(user, ';;;;;ewde')
    gIsLoginUser = true
    // document.querySelector('.user')
    renderUser()
    renderCustomers()
    const userToSave = { _id: user._id, fullname: user.fullname }
    sessionStorage.setItem(STORAGE_KEY_LOGGEDIN_USER, JSON.stringify(userToSave))
    return userToSave
}

function logout() {
    sessionStorage.removeItem(STORAGE_KEY_LOGGEDIN_USER)
    gIsLoginUser = false
    // document.querySelector('.user')
    renderUser()
    return Promise.resolve()
}
