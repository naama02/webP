
// Var that is used throughout this Module (not global)
const STORAGE_MAP_KEY = 'mapDB'
const API_KEY = 'AIzaSyCbP9OGR-VW640Uj_qlhro2bwGN6JXRxe8'
var gMap
let gMarkers = []

function initMap(lat = 32.0749831, lng = 34.9120554) {
    return _connectGoogleApi().then(() => {
        gMap = new google.maps.Map(document.querySelector('#map'), {
            center: { lat, lng },
            zoom: 15,
            // marker: [{ lat: 32.0749831, lng: 34.9120554 }]
        })

        new google.maps.Marker({
            position: { lat: 32.0749831, lng: 34.9120554 },
            gMap,
            title: "Hello World!",
        });

        return gMap
    })
}

function _connectGoogleApi() {
    if (window.google) return Promise.resolve()
    const API_KEY = 'AIzaSyCbP9OGR-VW640Uj_qlhro2bwGN6JXRxe8'
    var elGoogleApi = document.createElement('script')
    elGoogleApi.src = `https://www.google.com/maps?sca_esv=586679140&output=search&q=%D7%92%D7%95%D7%92%D7%9C+%D7%9E%D7%A4%D7%95%D7%AA&source=lnms&entry=mc&sa=X&ved=2ahUKEwjdtb2is-yCAxVZQfEDHbPkDlEQ0pQJegQIDRAB${API_KEY}`
    elGoogleApi.async = true
    document.body.append(elGoogleApi)

    return new Promise((resolve, reject) => {
        elGoogleApi.onload = resolve
        elGoogleApi.onerror = () => reject('Google script failed to load')
    })
}


// not in use:

function addMarker(loc) {
    var marker = new google.maps.Marker({
        position: loc,
        map: gMap,
        title: 'Hello World!',
    })
    gMarkers.push(marker)
    // console.log('gMarkers', gMarkers)
}

function getMarkers() {
    return gMarkers
}

function removeMarkers() {
    gMarkers.forEach((marker) => marker.setMap(null))
}

function panTo(lat, lng) {
    var laLatLng = new google.maps.LatLng(lat, lng)
    gMap.panTo(laLatLng)
}



function getLocationByName(txt) {
    return axios
        .get(
            `https://maps.googleapis.com/maps/api/geocode/json?address=${txt}&key=${API_KEY}`
        )
        .then((loc) => {
            const { lat, lng } = loc.data.results[0].geometry.location
            return { lat, lng }
        })
        .catch((err) => {
            console.log('Not enabled to get any location / API Key wrong.', err)
            throw err
        })
}