'use strict'
// import axios from "axios";

// import { carService } from '../../simple-backend/public/services/car.service.js'


// carService.query()
//     .then(cars => {
//         console.log('Cars:', cars,'C$$$$$$$$$ars:')
//     })

let gItemsDB = ''
// 'user permission for dev and demo use'
let gIsLoginUser = true

function onInit() {
    // TODO: IF WE WANT TO GET DATA FROM MONGO DB BY fetch REQ.
    // await fetch('http://127.0.0.1:3040/api/car')
    //     .then(response => response.json())
    //     .then(data => gItemsDB = data)
    //     .catch(error => console.error(error));
    // move to about page
    // initMap()

    renderItems()
    // console.log(gItemsDB, 'gItemsDB')
}



function renderItems(gItemsFromDB) {
    // TODO: IF WE WANT TO GET DATA FROM MONGO DB BY fetch REQ.
    // gItems = gItemsFromDB
    // const items = await getItemsForDisplay(gItemsFromDB)

    // return items  after filtering
    const items = getItemsForDisplay()
    console.log(items, 'items after filtering')
    //[div,div,div,div]
    //'div','div','div','div'

    const strHTMLs = items.map(item => `
        <div class="${(item.isSold) ? 'done' : ''} item"  data='${item._id}'>
        <img class="img-item" src="https://ksp.co.il/shop/items/512/226902.jpg" width='175' height='130'>
            <span class="title">${item.txt}</span > 
            <span class="price">price:${item.price}</span > 
            <span class="price">${item.labels}</span > 


            <div  class="actions flex column">

               <div class="flex">
                <button onclick="onUpdateItem('${item._id}')" class="add-btn">Edit</button>
                <button onclick="onSaveChanges('${item._id, item.txt, item.price}')" class="add-btn">Save</button>
               </div>
            
               <div class="flex">
                 <button class="add-btn" onclick="onRemoveItem(event,'${item._id}')" >X</button>
                 <button  class="add-btn" onclick="onToggleItem('${item._id}')" >Sold  </button>
               </div>

            </div>
        </div>
    `)
    // console.log(strHTMLs,'strHTMLs')
    document.querySelector('ul').innerHTML = strHTMLs.join('')
    document.querySelector('span.total').innerText = getTotalCount()
    document.querySelector('span.active').innerText = getActiveCount()

    // console.log(strHTMLs.join(''), 'strHTMLs')
}

renderUser()
function renderUser(gItemsFromDB) {
    // console.log('user func')
    const user = getLoggedInUser()
    // getLoggedInUser
    // console.log(items, 'items')

    const strHTML = gIsLoginUser ? `
        <div>
         user: ${user.fulllname}
        </div>
        <button onclick="logout()">logout</button>
    `
        :
        'Login:'

    document.querySelector('.user').innerHTML = strHTML


    // console.log(strHTMLs.join(''), 'strHTMLs')
}

let gCred = { username: '', password: '' }
// let gCred = { username: 'aaa', password: '' }
// let gCred = { username: 'aaa', password: '123' }

// 

function onSetLogin(ev, inputClicked) { //onSetLogin(ev, 'username')
    ev.preventDefault()
    const value = ev.target.value
    console.log(value, 'value') // 'aaa'
    console.log('inputClicked', inputClicked) //'username'

    const username = (inputClicked === 'username') ? gCred.username = value : gCred.username
    const password = (inputClicked === 'password') ? gCred.password = value : gCred.password
    // let gCred = { username: 'aaa', password: '123' }

    console.log(gCred, 'gCred')

}

function getLogin(ev) {
    ev.preventDefault()
    login(gCred)
}
// getLoggedInUser

// function onSetLoginPass(ev, username) {
//     ev.preventDefault()
//     // console.log(ev,'ppp')
//     console.log(pass, 'pass')
//     login(pass)
// }
// getLoggedInUser


function onRemoveItem(ev, itemId) {
    ev.stopPropagation()
    // console.log(itemId,'itemId')
    // console.log('Removing:', itemId)
    removeItem(itemId)
    renderItems()
}

function onToggleItem(itemId) {
    // onUpdateItem(itemId)
    // console.log('Toggling:', itemId)
    toggleItem(itemId)
    renderItems()

    // edit(itemId)
}

function onSaveChanges(itemId) {
    edit()
    renderItems()
}

function onClickInput(ev, clickedBtn) {
    // console.log(typeof ev.target.value, 'ev')
    // console.log(typeof ev.target.value, 'ev')

    // console.log(ev ,'ev')
    // console.log(clickedBtn,'clickedBtn')

    saveTxtInput(ev, clickedBtn)
}

function onUpdateItem(itemId) {


    // console.log(itemId, 'itemId to edit')

    const idx = gItems.findIndex(item => item._id === itemId)
    // console.log(idx, 'idx')
    const elTxt = document.querySelector('[name=txt]').value = gItems[idx].txt
    const elPrice = document.querySelector('[name=price]').value = gItems[idx].price

    updateIdToEdit(itemId)
    // item._id

    // console.log(gItems[idx], 'gItems[idx]')



    // gItems.splice(idx, 1, itemId)

    // storageService.store(STORAGE_KEY, gItems)
    // return Promise.resolve(itemToSave)


    // ev.preventDefault()
    // const txt = elTxt.value

    // const elPrice = document.querySelector('[name=price]')
    // const price = elPrice.value
    // addItem(txt, price)
    // renderItems()
    // elTxt.value = ''
    renderItems(gItemsDB)
}

function onAddItem(ev) {
    ev.preventDefault()
    const elTxt = document.querySelector('[name=txt]')
    const txt = elTxt.value

    const elPrice = document.querySelector('[name=price]')
    const price = elPrice.value
    addItem(txt, price)//addAitem ('k',120)
    renderItems()
    elTxt.value = ''
}

// html : select: 'active'
// onSetFilter('active')

function onSetFilter(filterBy) {
    // console.log('filterBy:', filterBy)
    setFilter(filterBy)
    renderItems()
}


function onSetFilterByLabel(filterBy) {
    console.log('filterBy:', filterBy)
    // setFilter(filterBy)
    setFilterByLable(filterBy)
    renderItems()
}




function onSetFilterByTxt(txt) {
    console.log('Filtering by txt', txt)
    setFilterByTxt(txt) //8
    renderItems()
}


function toggleMenu() {
    // gModalIsOpen = !gModalIsOpen
    // onUserClick()
    if (!gIsLoginUser) {
        alert('Sorry, not authorized')
        return
    }

    document.body.classList.toggle('menu-open');
}


// function onUserClick() {
//     console.log('onUserClick() ')
//     //     <a href="./pages/customers.html"></a>
//     document.querySelector('.user_e').innerHTML = '<a href="./pages/customers.html"></a>'
// }