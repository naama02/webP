const express = require('express')

const { getIphones, removeIphone } = require('./iphone.controller')
const router = express.Router()

router.get('/', getIphones)


module.exports = router