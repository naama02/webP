const iphoneService = require('./iphone.service.js')

async function getIphones(req, res) {
  try {
    const filterBy = {
      txt: req.query.txt || ''
    }
    const iphones = await iphoneService.query(filterBy)
    res.json(iphones)
  } catch (err) {
    res.status(500).send({ err: 'Failed to get iphones' })
  }
}




module.exports = {
  getIphones,
}
