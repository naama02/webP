const dbService = require('../../services/db.service')
const utilService = require('../../services/util.service')
const ObjectId = require('mongodb').ObjectId

async function query(filterBy = { txt: '' }) {
  try {
    const criteria = {
      vendor: { $regex: filterBy.txt, $options: 'i' },
    }
    const collection = await dbService.getCollection('car')
    var iphones = await collection.find(criteria).toArray()
    return iphones
  } catch (err) {
    throw err
  }
}




module.exports = {
  query,
}
