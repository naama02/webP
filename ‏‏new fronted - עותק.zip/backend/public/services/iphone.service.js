
import { httpService } from './http.service.js'
import { utilService } from './util.service.js'

const STORAGE_KEY = 'car'

export const iphoneService = {
    query,
    remove,
}
window.cs = iphoneService


async function query(filterBy = { txt: '', price: 0 }) {
    return httpService.get(STORAGE_KEY, filterBy)
}

async function remove(iphoneId) {
    return httpService.delete(`iphone/${iphoneId}`)
}

