import { iphoneService } from './services/iphone.service.js'
import { utilService } from './services/util.service.js'

console.log('Simple driver to test some API calls')

window.onLoadIphones = onLoadIphones
window.onRemoveIphone = onRemoveIphone

async function onLoadIphones() {
    const iphone = await iphoneService.query()
    render('Iphones', iphone)
}



function render(title, mix = '') {
    console.log(title, mix)
    const output = utilService.prettyJSON(mix)
    document.querySelector('h2').innerText = title
    document.querySelector('pre').innerHTML = output
}

