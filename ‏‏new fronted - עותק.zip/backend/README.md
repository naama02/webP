mister-backend is a powerful backend with:
*. Auth and REST
*. Route splitting
*. Middlewares
*. Logger
*. Config
*. MongoDB filtering
*. MongoDB ObjectId
*. ( _id vs id ) - Pushing data into an array in a MongoDB document
*. Vanilla frontend as a driver for testing    
